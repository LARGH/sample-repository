/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: DominioPagosImss.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.dominio;

import java.io.Serializable;

/**
 *
 * @author Jaime Landa
 */
public class DominioPagosImss implements Serializable {
    private long imss;
    private long rcv;
    private long info;
    private long totalMes;
    private long totalAnual;

    /**
     * @return the imss
     */
    public long getImss() {
        return imss;
    }

    /**
     * @param imss the imss to set
     */
    public void setImss(long imss) {
        this.imss = imss;
    }

    /**
     * @return the rcv
     */
    public long getRcv() {
        return rcv;
    }

    /**
     * @param rcv the rcv to set
     */
    public void setRcv(long rcv) {
        this.rcv = rcv;
    }

    /**
     * @return the info
     */
    public long getInfo() {
        return info;
    }

    /**
     * @param info the info to set
     */
    public void setInfo(long info) {
        this.info = info;
    }

    /**
     * @return the totalMes
     */
    public long getTotalMes() {
        return totalMes;
    }

    /**
     * @param totalMes the totalMes to set
     */
    public void setTotalMes(long totalMes) {
        this.totalMes = totalMes;
    }

    /**
     * @return the totalAnual
     */
    public long getTotalAnual() {
        return totalAnual;
    }

    /**
     * @param totalAnual the totalAnual to set
     */
    public void setTotalAnual(long totalAnual) {
        this.totalAnual = totalAnual;
    }
}
