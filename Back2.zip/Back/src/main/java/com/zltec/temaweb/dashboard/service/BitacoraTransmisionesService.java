/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: BitacoraTransmisionesService.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.service;

import com.zltec.temaweb.dashboard.dominio.DominioDashboardResponse;
import com.zltec.temaweb.dashboard.repository.IBitacoraTransmisionesRepository;
import com.zltec.temaweb.dashboard.excepcion.CustomException;
import com.zltec.temaweb.dashboard.utils.JRUtil;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class BitacoraTransmisionesService implements IBitacoraTransmisionesService {
    private static final Logger LOG = LoggerFactory.getLogger(BitacoraTransmisionesService.class);
    @Autowired
    private IBitacoraTransmisionesRepository bitacoraTransmisionesRepository;

    @Override
    public void getTransmisiones(DominioDashboardResponse dom) throws CustomException {
        if(dom.getTest() == 1) {
            dom.getMovimientosTransmitidos().setA02BajasAnualTransmitidos(getNumeroRandom());
            dom.getMovimientosTransmitidos().setA02BajasMesTransmitidos(getNumeroRandom());
            dom.getMovimientosTransmitidos().setA07CambiosAnualTransmitidos(getNumeroRandom());
            dom.getMovimientosTransmitidos().setA07CambiosMesTransmitidos(getNumeroRandom());
            dom.getMovimientosTransmitidos().setA08AltasAnualTransmitidos(getNumeroRandom());
            dom.getMovimientosTransmitidos().setA08AltasMesTransmitidos(getNumeroRandom());
            dom.getMovimientosTransmitidos().setTotalMesTransmitidos(dom.getMovimientosTransmitidos().getA02BajasMesTransmitidos()+dom.getMovimientosTransmitidos().getA07CambiosMesTransmitidos()+dom.getMovimientosTransmitidos().getA08AltasMesTransmitidos());
            dom.getMovimientosTransmitidos().setTotalAnualTransmitidos(dom.getMovimientosTransmitidos().getA02BajasAnualTransmitidos()+dom.getMovimientosTransmitidos().getA07CambiosAnualTransmitidos()+dom.getMovimientosTransmitidos().getA08AltasAnualTransmitidos());
        } else {
            LOG.info("##### User10: "+dom.getUsername());
            LOG.info("##### Clave de División: "+dom.getClaveDivision());
            Map<String, Object> responseXMes = bitacoraTransmisionesRepository.
                    filtraTransmisionesXMes(dom.getClaveDivision(), dom.getUsername());
            if(responseXMes != null) {
                setResponseTransmisionesXMes(dom, responseXMes);
            }
            Map<String, Object> responseAnual = bitacoraTransmisionesRepository.
                    filtraTransmisionesAnual(dom.getClaveDivision(), dom.getUsername());
            if(responseAnual != null) {
                setResponseTransmisionesAnual(dom, responseAnual);
            }
        }
    }
    
    private void setResponseTransmisionesXMes(DominioDashboardResponse dom, Map<String, Object> responseXMes) {
        if(responseXMes.get("bajas") != null) {
            dom.getMovimientosTransmitidos().setA02BajasMesTransmitidos(Long.parseLong(""+responseXMes.get("bajas")));
        }
        if(responseXMes.get("cambios") != null) {
            dom.getMovimientosTransmitidos().setA07CambiosMesTransmitidos(Long.parseLong(""+responseXMes.get("cambios")));
        }
        if(responseXMes.get("altas") != null) {
            dom.getMovimientosTransmitidos().setA08AltasMesTransmitidos(Long.parseLong(""+responseXMes.get("altas")));
        }
        dom.getMovimientosTransmitidos().setTotalMesTransmitidos(dom.getMovimientosTransmitidos().getA02BajasMesTransmitidos()+dom.getMovimientosTransmitidos().getA07CambiosMesTransmitidos()+dom.getMovimientosTransmitidos().getA08AltasMesTransmitidos());
    }
    
    private void setResponseTransmisionesAnual(DominioDashboardResponse dom, Map<String, Object> responseAnual) {
        if(responseAnual.get("bajas") != null) {
            dom.getMovimientosTransmitidos().setA02BajasAnualTransmitidos(Long.parseLong(""+responseAnual.get("bajas")));
        }
        if(responseAnual.get("cambios") != null) {
            dom.getMovimientosTransmitidos().setA07CambiosAnualTransmitidos(Long.parseLong(""+responseAnual.get("cambios")));
        }
        if(responseAnual.get("altas") != null) {
            dom.getMovimientosTransmitidos().setA08AltasAnualTransmitidos(Long.parseLong(""+responseAnual.get("altas")));
        }
        dom.getMovimientosTransmitidos().setTotalAnualTransmitidos(dom.getMovimientosTransmitidos().getA02BajasAnualTransmitidos()+dom.getMovimientosTransmitidos().getA07CambiosAnualTransmitidos()+dom.getMovimientosTransmitidos().getA08AltasAnualTransmitidos());
    }
    
    //Solo para pruebas
    private long getNumeroRandom() {
        int limite = 100;
        return Long.parseLong(""+JRUtil.numeroRandom(limite));
    }
}
