/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: DefaultErrorList.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/

package com.zltec.temaweb.dashboard.excepcion.util;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * La clase DefaultErrorList, usada para enviar la respuesta en caso de error durante la ejecucion del servicio.
 * 
 * @author Jaime Landa 
 */
public class DefaultErrorList implements Serializable {

    /**
     * Variable para serializar la clase.
     */
    private static final long serialVersionUID = 1L;

    /**
     * La variable errors.
     */
    private List<DefaultError> errors;

    /**
     * Constructor de la clase. Un ejemplo de implementacion es agregar la
     * siguiente linea:
     *
     * DefaultErrorResponseBean errorResp = new DefaultErrorResponseBean(new
     * ErrorBean(ErrorEnum.FORBIDDEN));
     *
     * En donde el objeto ErrorEnum es la clase con la serie de codigos de
     * errores (Puede utilizarse esa misma clase generica, o una implementacion
     * propia)
     */
    public DefaultErrorList(final DefaultError errorBean) {
        this.add(errorBean);
    }

    /**
     * Obtiene el valor de la variable errors.
     *
     * @return el errors
     */
    public List<DefaultError> getErrors() {
        return errors;
    }

    /**
     * Coloca el valor de errors.
     *
     * @param errors es el nuevo valor de errors
     */
    public void setErrors(List<DefaultError> errors) {
        this.errors = errors;
    }

    /**
     * Adds the.
     *
     * @param errorBean el parametro error bean
     */
    public void add(final DefaultError errorBean) {
        if (this.errors == null || this.errors.isEmpty()) {
            this.errors = new ArrayList<>();
        }
        this.errors.add(errorBean);
    }

    /**
     * @return El json en string del objeto completo
     * @throws JsonProcessingException Cuando existe error en el parseo
     */
    public String toJsonString() throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(this);
    }
}
