/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: DominioBitacoraTransmisiones.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.dominio;

import java.util.Date;
import java.math.BigDecimal;

public class DominioBitacoraTransmisiones extends GenericDominio {
    private static final long serialVersionUID = -8617407926402928640L;
    private DominioBitacoraTransmisionesId id;
    private String claveDivision;
    private String claveZona;
    private String claveCentro;
    private Date fechaTransmision;
    private String clavePatronal;
    private String claveUsuario;
    private Long loteEnviado;
    private Long loteAcuseImss;
    private Long loteRespuestaImss;
    private Date fechaRecepcion;
    private String archivoEnviado;
    private String archivoRecibido;
    private String archivoAcuse;
    private Long a08Transmitidos;
    private Long a07Transmitidos;
    private Long a02Transmitidos;
    private Long a08Operados;
    private Long a07Operados;
    private Long a02Operados;
    private Long a08Erroneos;
    private Long a07Erroneos;
    private Long a02Erroneos;
    private Long a08OpeAcuse;
    private Long a07OpeAcuse;
    private Long a02OpeAcuse;
    private Long a08ErrAcuse;
    private Long a07ErrAcuse;
    private Long a02ErrAcuse;
    private BigDecimal totalMovimientos;
    private String estatus;
    private Date fechaTransaccion;
    private BigDecimal idTransmision;
    private String idCliente;
    private String idCentroCostos;
    private String archivoRspTxt;
    private String archivoRspImss;
    private Long idProceso;

    public DominioBitacoraTransmisiones() {
        id = new DominioBitacoraTransmisionesId();
    }

    public void setId(DominioBitacoraTransmisionesId id) {
        this.id = id;
    }
    public DominioBitacoraTransmisionesId getId() {
        return id;
    }
    public void setClaveDivision(String claveDivision) {
        this.claveDivision = claveDivision;
    }
    public String getClaveDivision() {
        return claveDivision;
    }
    public void setClaveZona(String claveZona) {
        this.claveZona = claveZona;
    }
    public String getClaveZona() {
        return claveZona;
    }
    public void setClaveCentro(String claveCentro) {
        this.claveCentro = claveCentro;
    }
    public String getClaveCentro() {
        return claveCentro;
    }
    public void setFechaTransmision(Date fechaTransmision) {
        this.fechaTransmision = fechaTransmision;
    }
    public Date getFechaTransmision() {
        return fechaTransmision;
    }
    public void setClavePatronal(String clavePatronal) {
        this.clavePatronal = clavePatronal;
    }
    public String getClavePatronal() {
        return clavePatronal;
    }
    public void setClaveUsuario(String claveUsuario) {
        this.claveUsuario = claveUsuario;
    }
    public String getClaveUsuario() {
        return claveUsuario;
    }
    public void setLoteEnviado(Long loteEnviado) {
        this.loteEnviado = loteEnviado;
    }
    public Long getLoteEnviado() {
        return loteEnviado;
    }
    public void setLoteAcuseImss(Long loteAcuseImss) {
        this.loteAcuseImss = loteAcuseImss;
    }
    public Long getLoteAcuseImss() {
        return loteAcuseImss;
    }
    public void setLoteRespuestaImss(Long loteRespuestaImss) {
        this.loteRespuestaImss = loteRespuestaImss;
    }
    public Long getLoteRespuestaImss() {
        return loteRespuestaImss;
    }
    public void setFechaRecepcion(Date fechaRecepcion) {
        this.fechaRecepcion = fechaRecepcion;
    }
    public Date getFechaRecepcion() {
        return fechaRecepcion;
    }
    public void setArchivoEnviado(String archivoEnviado) {
        this.archivoEnviado = archivoEnviado;
    }
    public String getArchivoEnviado() {
        return archivoEnviado;
    }
    public void setArchivoRecibido(String archivoRecibido) {
        this.archivoRecibido = archivoRecibido;
    }
    public String getArchivoRecibido() {
        return archivoRecibido;
    }
    public void setArchivoAcuse(String archivoAcuse) {
        this.archivoAcuse = archivoAcuse;
    }
    public String getArchivoAcuse() {
        return archivoAcuse;
    }
    public void setA08Transmitidos(Long a08Transmitidos) {
        this.a08Transmitidos = a08Transmitidos;
    }
    public Long getA08Transmitidos() {
        return a08Transmitidos;
    }
    public void setA07Transmitidos(Long a07Transmitidos) {
        this.a07Transmitidos = a07Transmitidos;
    }
    public Long getA07Transmitidos() {
        return a07Transmitidos;
    }
    public void setA02Transmitidos(Long a02Transmitidos) {
        this.a02Transmitidos = a02Transmitidos;
    }
    public Long getA02Transmitidos() {
        return a02Transmitidos;
    }
    public void setA08Operados(Long a08Operados) {
        this.a08Operados = a08Operados;
    }
    public Long getA08Operados() {
        return a08Operados;
    }
    public void setA07Operados(Long a07Operados) {
        this.a07Operados = a07Operados;
    }
    public Long getA07Operados() {
        return a07Operados;
    }
    public void setA02Operados(Long a02Operados) {
        this.a02Operados = a02Operados;
    }
    public Long getA02Operados() {
        return a02Operados;
    }
    public void setA08Erroneos(Long a08Erroneos) {
        this.a08Erroneos = a08Erroneos;
    }
    public Long getA08Erroneos() {
        return a08Erroneos;
    }
    public void setA07Erroneos(Long a07Erroneos) {
        this.a07Erroneos = a07Erroneos;
    }
    public Long getA07Erroneos() {
        return a07Erroneos;
    }
    public void setA02Erroneos(Long a02Erroneos) {
        this.a02Erroneos = a02Erroneos;
    }
    public Long getA02Erroneos() {
        return a02Erroneos;
    }
    public void setA08OpeAcuse(Long a08OpeAcuse) {
        this.a08OpeAcuse = a08OpeAcuse;
    }
    public Long getA08OpeAcuse() {
        return a08OpeAcuse;
    }
    public void setA07OpeAcuse(Long a07OpeAcuse) {
        this.a07OpeAcuse = a07OpeAcuse;
    }
    public Long getA07OpeAcuse() {
        return a07OpeAcuse;
    }
    public void setA02OpeAcuse(Long a02OpeAcuse) {
        this.a02OpeAcuse = a02OpeAcuse;
    }
    public Long getA02OpeAcuse() {
        return a02OpeAcuse;
    }
    public void setA08ErrAcuse(Long a08ErrAcuse) {
        this.a08ErrAcuse = a08ErrAcuse;
    }
    public Long getA08ErrAcuse() {
        return a08ErrAcuse;
    }
    public void setA07ErrAcuse(Long a07ErrAcuse) {
        this.a07ErrAcuse = a07ErrAcuse;
    }
    public Long getA07ErrAcuse() {
        return a07ErrAcuse;
    }
    public void setA02ErrAcuse(Long a02ErrAcuse) {
        this.a02ErrAcuse = a02ErrAcuse;
    }
    public Long getA02ErrAcuse() {
        return a02ErrAcuse;
    }
    public void setTotalMovimientos(BigDecimal totalMovimientos) {
        this.totalMovimientos = totalMovimientos;
    }
    public BigDecimal getTotalMovimientos() {
        return totalMovimientos;
    }
    public void setEstatus(String estatus) {
        this.estatus = estatus;
    }
    public String getEstatus() {
        return estatus;
    }
    public void setFechaTransaccion(Date fechaTransaccion) {
        this.fechaTransaccion = fechaTransaccion;
    }
    public Date getFechaTransaccion() {
        return fechaTransaccion;
    }
    public void setIdTransmision(BigDecimal idTransmision) {
        this.idTransmision = idTransmision;
    }
    public BigDecimal getIdTransmision() {
        return idTransmision;
    }
    public void setIdCliente(String idCliente) {
        this.idCliente = idCliente;
    }
    public String getIdCliente() {
        return idCliente;
    }
    public void setIdCentroCostos(String idCentroCostos) {
        this.idCentroCostos = idCentroCostos;
    }
    public String getIdCentroCostos() {
        return idCentroCostos;
    }
    public void setArchivoRspTxt(String archivoRspTxt) {
        this.archivoRspTxt = archivoRspTxt;
    }
    public String getArchivoRspTxt() {
        return archivoRspTxt;
    }
    public void setArchivoRspImss(String archivoRspImss) {
        this.archivoRspImss = archivoRspImss;
    }
    public String getArchivoRspImss() {
        return archivoRspImss;
    }
    public void setIdProceso(Long idProceso) {
        this.idProceso = idProceso;
    }
    public Long getIdProceso() {
        return idProceso;
    }
}
