/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: IRegistrosPatronalesRepository.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.repository;

import com.zltec.temaweb.dashboard.jpa.entity.BitacoraTransmisiones;
import com.zltec.temaweb.dashboard.jpa.entity.BitacoraTransmisionesId;
import java.util.Map;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface IRegistrosPatronalesRepository extends JpaRepository<BitacoraTransmisiones, BitacoraTransmisionesId> {
    String QUERY_TAG_REGISTROS_PATRONALES =
            "SELECT " +
            "SUM(TOTAL_IMSS_MENSUAL) AS imss," +
            "SUM(TOTAL_IMSS_BIMESTRAL) AS rcv," +
            "SUM(TOTAL_INFONAVIT) AS info " +
            "FROM BLOQUE_PAGO_PATRON " +
            "WHERE CLAVE_PATRONAL = :clavePatronal " +
            "AND (" +
            "	FECHA_SMGDF >= (select dateadd(d,-(day(getdate()-1)),getdate()))" +
            "	AND FECHA_SMGDF <= getdate()" +
            ")";
    
    @Query(value = QUERY_TAG_REGISTROS_PATRONALES, nativeQuery = true)
    public Map<String, Object> filtraRegistrosPatronales(
        @Param("clavePatronal")String clavePatronal
    );
}
