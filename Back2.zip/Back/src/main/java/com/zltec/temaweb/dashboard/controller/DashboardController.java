/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: DashboardController.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.controller;

import com.zltec.temaweb.dashboard.service.IBitacoraTransmisionesService;
import com.zltec.temaweb.dashboard.dominio.DominioDashboardResponse;
import com.zltec.temaweb.dashboard.excepcion.CustomException;
import com.zltec.temaweb.dashboard.service.IPagosImssService;
import com.zltec.temaweb.dashboard.service.IRegistrosPatronalesService;
import com.zltec.temaweb.dashboard.service.ITrabajadoresService;
import java.io.IOException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

@RestController
@RequestMapping(path = "/servicesREST/Dashboard")
public class DashboardController {
    private static final Logger LOG = LoggerFactory.getLogger(DashboardController.class);
    @Autowired
    private IBitacoraTransmisionesService bitacoraTransmisionesService;
    @Autowired
    private IPagosImssService pagosImssService;
    @Autowired
    private ITrabajadoresService trabajadoresService;
    @Autowired
    private IRegistrosPatronalesService registrosPatronalesService;
    
    @RequestMapping(
        method = RequestMethod.GET, path = "/connectDashboard",
        produces = MediaType.TEXT_EVENT_STREAM_VALUE
    )
    public SseEmitter connectDashboard(@RequestParam(name = "username") String username,
            @RequestParam(name = "claveDivision") String claveDivision,
            @RequestParam(name = "test") int test) 
            throws CustomException, IOException {
        LOG.info("#### DashboardController username: "+username);
        LOG.info("#### DashboardController claveDivision: "+claveDivision);
        LOG.info("#### DashboardController test: "+test);
        SseEmitter emitter = new SseEmitter();
        DominioDashboardResponse dom = getData(username, claveDivision, test);
        emitter.send(dom);
        emitter.complete();
        LOG.info("#### SseEmitter send TotalMesTransmitidos: "+dom.getMovimientosTransmitidos().getTotalMesTransmitidos());
        return emitter;
    }
    
    private DominioDashboardResponse getData(String username, String claveDivision, int test) {
        LOG.info("##### DashboardController::getData. . .");
        DominioDashboardResponse dom = new DominioDashboardResponse();
        dom.setCode(500);
        try {
            String userName10 = username;
            if (username != null && username.length() > 10) {
                userName10 = username.substring(0, 10);
            }
            dom.setClaveDivision(claveDivision);
            dom.setUsername(userName10);
            dom.setTest(test);
            bitacoraTransmisionesService.getTransmisiones(dom);
            pagosImssService.getPagosImss(dom);
            trabajadoresService.getTrabajadores(dom);
            registrosPatronalesService.getRegistrosPatronales(dom);
            dom.setCode(200);
        } catch(CustomException ex){
            dom.setCodError("501");
        }
        return dom;
    }
}
