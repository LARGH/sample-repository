/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: DominioDashboardResponse.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.dominio;
/**
 *
 * @author Jaime Landa
 */
public class DominioDashboardResponse extends GenericDominio {
    private int test;
    private String claveDivision;
    private String clavePatronal;
    private String username;
    private DominioMovimientosTransmitidos movimientosTransmitidos;
    private DominioPagosImss pagosImss;
    
    public DominioDashboardResponse() {
        movimientosTransmitidos = new DominioMovimientosTransmitidos();
        pagosImss = new DominioPagosImss();
    }

    /**
     * @return the test
     */
    public int getTest() {
        return test;
    }

    /**
     * @param test the test to set
     */
    public void setTest(int test) {
        this.test = test;
    }

    /**
     * @return the claveDivision
     */
    public String getClaveDivision() {
        return claveDivision;
    }

    /**
     * @param claveDivision the claveDivision to set
     */
    public void setClaveDivision(String claveDivision) {
        this.claveDivision = claveDivision;
    }

    /**
     * @return the clavePatronal
     */
    public String getClavePatronal() {
        return clavePatronal;
    }

    /**
     * @param clavePatronal the clavePatronal to set
     */
    public void setClavePatronal(String clavePatronal) {
        this.clavePatronal = clavePatronal;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username the username to set
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * @return the movimientosTransmitidos
     */
    public DominioMovimientosTransmitidos getMovimientosTransmitidos() {
        return movimientosTransmitidos;
    }

    /**
     * @param movimientosTransmitidos the movimientosTransmitidos to set
     */
    public void setMovimientosTransmitidos(DominioMovimientosTransmitidos movimientosTransmitidos) {
        this.movimientosTransmitidos = movimientosTransmitidos;
    }

    /**
     * @return the pagosImss
     */
    public DominioPagosImss getPagosImss() {
        return pagosImss;
    }

    /**
     * @param pagosImss the pagosImss to set
     */
    public void setPagosImss(DominioPagosImss pagosImss) {
        this.pagosImss = pagosImss;
    }
}
