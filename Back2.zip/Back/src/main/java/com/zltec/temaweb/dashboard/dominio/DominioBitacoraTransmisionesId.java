/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: DominioBitacoraTransmisionesId.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.dominio;

import java.util.Date;

public class DominioBitacoraTransmisionesId extends GenericDominio {
    private static final long serialVersionUID = -2387739147369335808L;
    private String claveDivision;
    private String claveZona;
    private String claveCentro;
    private Date fechaTransmision;
    private String clavePatronal;
    private String claveUsuario;

    public DominioBitacoraTransmisionesId() {
    }

    public void setClaveDivision(String claveDivision) {
        this.claveDivision = claveDivision;
    }
    public String getClaveDivision() {
        return claveDivision;
    }
    public void setClaveZona(String claveZona) {
        this.claveZona = claveZona;
    }
    public String getClaveZona() {
        return claveZona;
    }
    public void setClaveCentro(String claveCentro) {
        this.claveCentro = claveCentro;
    }
    public String getClaveCentro() {
        return claveCentro;
    }
    public void setFechaTransmision(Date fechaTransmision) {
        this.fechaTransmision = fechaTransmision;
    }
    public Date getFechaTransmision() {
        return fechaTransmision;
    }
    public void setClavePatronal(String clavePatronal) {
        this.clavePatronal = clavePatronal;
    }
    public String getClavePatronal() {
        return clavePatronal;
    }
    public void setClaveUsuario(String claveUsuario) {
        this.claveUsuario = claveUsuario;
    }
    public String getClaveUsuario() {
        return claveUsuario;
    }
}
