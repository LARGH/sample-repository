/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: DominioTrabajadoresyrp.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.dominio;

import java.io.Serializable;

/**
 *
 * @author Jaime Landa
 */
public class DominioTrabajadoresyrp implements Serializable {
    private long total;
    private long tagSaludTuEmpresa;
    private long servSubcontra;
    private long servIntAdecco;
    private long reussiteAdecco;
    private long performanceAdecco;
    private long logisExpert;
    private long expertosBO;
    private long enterpriseAdecco;
    private long expertosAA;
    private long adeccoLatamBS;

    /**
     * @return the total
     */
    public long getTotal() {
        return total;
    }

    /**
     * @param total the total to set
     */
    public void setTotal(long total) {
        this.total = total;
    }

    /**
     * @return the tagSaludTuEmpresa
     */
    public long getTagSaludTuEmpresa() {
        return tagSaludTuEmpresa;
    }

    /**
     * @param tagSaludTuEmpresa the tagSaludTuEmpresa to set
     */
    public void setTagSaludTuEmpresa(long tagSaludTuEmpresa) {
        this.tagSaludTuEmpresa = tagSaludTuEmpresa;
    }

    /**
     * @return the servSubcontra
     */
    public long getServSubcontra() {
        return servSubcontra;
    }

    /**
     * @param servSubcontra the servSubcontra to set
     */
    public void setServSubcontra(long servSubcontra) {
        this.servSubcontra = servSubcontra;
    }

    /**
     * @return the servIntAdecco
     */
    public long getServIntAdecco() {
        return servIntAdecco;
    }

    /**
     * @param servIntAdecco the servIntAdecco to set
     */
    public void setServIntAdecco(long servIntAdecco) {
        this.servIntAdecco = servIntAdecco;
    }

    /**
     * @return the reussiteAdecco
     */
    public long getReussiteAdecco() {
        return reussiteAdecco;
    }

    /**
     * @param reussiteAdecco the reussiteAdecco to set
     */
    public void setReussiteAdecco(long reussiteAdecco) {
        this.reussiteAdecco = reussiteAdecco;
    }

    /**
     * @return the performanceAdecco
     */
    public long getPerformanceAdecco() {
        return performanceAdecco;
    }

    /**
     * @param performanceAdecco the performanceAdecco to set
     */
    public void setPerformanceAdecco(long performanceAdecco) {
        this.performanceAdecco = performanceAdecco;
    }

    /**
     * @return the logisExpert
     */
    public long getLogisExpert() {
        return logisExpert;
    }

    /**
     * @param logisExpert the logisExpert to set
     */
    public void setLogisExpert(long logisExpert) {
        this.logisExpert = logisExpert;
    }

    /**
     * @return the expertosBO
     */
    public long getExpertosBO() {
        return expertosBO;
    }

    /**
     * @param expertosBO the expertosBO to set
     */
    public void setExpertosBO(long expertosBO) {
        this.expertosBO = expertosBO;
    }

    /**
     * @return the enterpriseAdecco
     */
    public long getEnterpriseAdecco() {
        return enterpriseAdecco;
    }

    /**
     * @param enterpriseAdecco the enterpriseAdecco to set
     */
    public void setEnterpriseAdecco(long enterpriseAdecco) {
        this.enterpriseAdecco = enterpriseAdecco;
    }

    /**
     * @return the expertosAA
     */
    public long getExpertosAA() {
        return expertosAA;
    }

    /**
     * @param expertosAA the expertosAA to set
     */
    public void setExpertosAA(long expertosAA) {
        this.expertosAA = expertosAA;
    }

    /**
     * @return the adeccoLatamBS
     */
    public long getAdeccoLatamBS() {
        return adeccoLatamBS;
    }

    /**
     * @param adeccoLatamBS the adeccoLatamBS to set
     */
    public void setAdeccoLatamBS(long adeccoLatamBS) {
        this.adeccoLatamBS = adeccoLatamBS;
    }

}
