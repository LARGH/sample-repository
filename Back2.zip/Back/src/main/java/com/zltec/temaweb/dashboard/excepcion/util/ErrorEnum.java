/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: ErrorEnum.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/

package com.zltec.temaweb.dashboard.excepcion.util;

/**
 * The Enum ErrorEnum.
 * @author Jaime Landa
 */
public enum ErrorEnum {

    GENERICO("GEN.000", "Error generico", "Error generico de este servicio", "Error", ""),
    ERROR_PARAMS("GEN.001", "Parametros invalidos", "Parametros invalidos de este servicio", "Error", ""),
    NO_ENCONTRADO("GEN.100", "No encontrado", "Recurso no encontrado", "Error", "");

    private final String code;

    private final String message;

    private final String description;

    private final String level;

    private final String moreInfo;

    private ErrorEnum(final String code, final String message,
            final String description, final String level, final String moreInfo) {
        this.code = code;
        this.message = message;
        this.description = description;
        this.level = level;
        this.moreInfo = moreInfo;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public String getDescription() {
        return description;
    }

    public String getLevel() {
        return level;
    }

    public String getMoreInfo() {
        return moreInfo;
    }
}

