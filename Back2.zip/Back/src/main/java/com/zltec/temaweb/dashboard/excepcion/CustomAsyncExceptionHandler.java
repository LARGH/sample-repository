/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: CustomAsyncExceptionHandler.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/

package com.zltec.temaweb.dashboard.excepcion;

import java.lang.reflect.Method;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;

public class CustomAsyncExceptionHandler implements AsyncUncaughtExceptionHandler {
    private static final Logger LOG = LoggerFactory.getLogger(CustomAsyncExceptionHandler.class);
 
    @Override
    public void handleUncaughtException(Throwable throwable, Method method, Object... obj) {
        LOG.error("CustomAsyncExceptionHandler.Exception message - " + throwable.getMessage());
        LOG.error("CustomAsyncExceptionHandler.Method name - " + method.getName());
        for (Object param : obj) {
            LOG.error("CustomAsyncExceptionHandler.Parameter value - " + param);
        }
    }
}
