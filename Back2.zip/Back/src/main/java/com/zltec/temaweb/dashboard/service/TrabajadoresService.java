/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: TrabajadoresService.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.service;

import com.zltec.temaweb.dashboard.dominio.DominioDashboardResponse;
import com.zltec.temaweb.dashboard.excepcion.CustomException;
import com.zltec.temaweb.dashboard.repository.ITrabajadoresRepository;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Jaime Landa
 */
@Service
public class TrabajadoresService implements ITrabajadoresService {
    private static final Logger LOG = LoggerFactory.getLogger(TrabajadoresService.class);
    @Autowired
    private ITrabajadoresRepository trabajadoresRepository;

    @Override
    public void getTrabajadores(DominioDashboardResponse dom) throws CustomException {
        LOG.info("##### User10: "+dom.getUsername());
        LOG.info("##### Clave de División: "+dom.getClaveDivision());
        /*Map<String, Object> responseXMes = trabajadoresRepository.
                filtraTrabajadoresXMes(dom.getClavePatronal());
        if(responseXMes != null) {
            setResponseTransmisionesXMes(dom, responseXMes);
        }
        Map<String, Object> responseAnual = trabajadoresRepository.
                filtraTrabajadoresAnual(dom.getClavePatronal());
        if(responseAnual != null) {
            setResponseTransmisionesAnual(dom, responseAnual);
        }*/
    }
}
