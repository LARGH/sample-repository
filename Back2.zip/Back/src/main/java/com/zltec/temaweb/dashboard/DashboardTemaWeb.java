/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: DashboardTemaWeb.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/

package com.zltec.temaweb.dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

@SpringBootApplication
@EnableDiscoveryClient
@ComponentScan(basePackages = "com.zltec.temaweb.dashboard")
@EnableJpaRepositories(basePackages="com.zltec.temaweb.dashboard.repository")
@EntityScan(basePackages = "com.zltec.temaweb.dashboard.jpa.entity")
public class DashboardTemaWeb {
    private static final Logger LOG = LoggerFactory.getLogger(DashboardTemaWeb.class);

    /**
     * Método principal que inicializa el aplicativo con Spring Boot.
     *
     * @param args
     */
    public static void main(String[] args) {
        LOG.info("######## invoke DashboardTemaWeb.main. . .");
        SpringApplication.run(DashboardTemaWeb.class, args);
    }
}
