/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: CustomException.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/

package com.zltec.temaweb.dashboard.excepcion;

import com.zltec.temaweb.dashboard.excepcion.util.ErrorEnum;

public class CustomException extends Exception {
    @SuppressWarnings("compatibility:-8417475342587208891")
    private static final long serialVersionUID = -1127219831870567637L;
    private ErrorEnum error;

    /**
     * Constructor
     * @param message Mensaje de error
     */
    public CustomException(String message) {
        super(message);
    }

    /**
     * Constructor
     * @param message Mensaje de error
     * @param causa Causa completa del error
     */
    public CustomException(String message, Throwable causa) {
        super(message, causa);
    }

    /**
     * Constructor que la interfaz del enumerador de error
     * @param errorEnum Interfaz de enumerador de error
     */
    public CustomException(ErrorEnum errorEnum) {
        super(errorEnum.getMessage());
        this.error = errorEnum;
    }
    
    /**
     * Constructor que la interfaz del enumerador de error
     * @param errorEnum Interfaz de enumerador de error
     * @param causa Causa completa del error
     */
    public CustomException(ErrorEnum errorEnum, Throwable causa) {
        super(errorEnum.getMessage(), causa);
    }
    
    public ErrorEnum getError() {
        return error;
    }

    public void setError(ErrorEnum error) {
        this.error = error;
    }
}
