/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: IBitacoraTransmisionesRepository.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.repository;

import com.zltec.temaweb.dashboard.jpa.entity.BitacoraTransmisiones;
import com.zltec.temaweb.dashboard.jpa.entity.BitacoraTransmisionesId;
import java.util.Map;
import org.springframework.stereotype.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface IBitacoraTransmisionesRepository extends JpaRepository<BitacoraTransmisiones, BitacoraTransmisionesId> {
    String QUERY_TRASMISIONES_MES =
            "SELECT " +
            "SUM(A02_TRANSMITIDOS) AS bajas," +
            "SUM(A07_TRANSMITIDOS) AS cambios," +
            "SUM(A08_TRANSMITIDOS) AS altas " +
            "FROM BITACORA_TRANSMISIONES " +
            "WHERE CLAVE_DIVISION = :claveDivision AND CLAVE_USUARIO = :username " +
            "AND (" +
            "	FECHA_TRANSMISION >= (select dateadd(d,-(day(getdate()-1)),getdate()))" +
            "	AND FECHA_TRANSMISION <= getdate()" +
            ")";
    
    @Query(value = QUERY_TRASMISIONES_MES, nativeQuery = true)
    public Map<String, Object> filtraTransmisionesXMes(
        @Param("claveDivision")String claveDivision,
        @Param("username")String username
    );
    
    String QUERY_TRASMISIONES_ANUAL =
            "SELECT " +
            "SUM(A02_TRANSMITIDOS) AS bajas," +
            "SUM(A07_TRANSMITIDOS) AS cambios," +
            "SUM(A08_TRANSMITIDOS) AS altas " +
            "FROM BITACORA_TRANSMISIONES " +
            "WHERE CLAVE_DIVISION = :claveDivision AND CLAVE_USUARIO = :username " +
            "AND (" +
            "	FECHA_TRANSMISION >= (select DATEADD(yy, DATEDIFF(yy, 0, GETDATE()), 0))" +
            "	AND FECHA_TRANSMISION <= getdate()" +
            ")";
    
    @Query(value = QUERY_TRASMISIONES_ANUAL, nativeQuery = true)
    public Map<String, Object> filtraTransmisionesAnual(
        @Param("claveDivision")String claveDivision,
        @Param("username")String username
    );
}
