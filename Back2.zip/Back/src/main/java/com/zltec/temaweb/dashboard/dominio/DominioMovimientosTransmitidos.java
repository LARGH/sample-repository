/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: DominioMovimientosTransmitidos.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.dominio;

import java.io.Serializable;

/**
 *
 * @author Jaime Landa
 */
public class DominioMovimientosTransmitidos implements Serializable {
    private long a08AltasMesTransmitidos;
    private long a08AltasAnualTransmitidos;
    private long a07CambiosMesTransmitidos;
    private long a07CambiosAnualTransmitidos;
    private long a02BajasMesTransmitidos;
    private long a02BajasAnualTransmitidos;
    private long totalMesTransmitidos;
    private long totalAnualTransmitidos;

    /**
     * @return the a08AltasMesTransmitidos
     */
    public long getA08AltasMesTransmitidos() {
        return a08AltasMesTransmitidos;
    }

    /**
     * @param a08AltasMesTransmitidos the a08AltasMesTransmitidos to set
     */
    public void setA08AltasMesTransmitidos(long a08AltasMesTransmitidos) {
        this.a08AltasMesTransmitidos = a08AltasMesTransmitidos;
    }

    /**
     * @return the a08AltasAnualTransmitidos
     */
    public long getA08AltasAnualTransmitidos() {
        return a08AltasAnualTransmitidos;
    }

    /**
     * @param a08AltasAnualTransmitidos the a08AltasAnualTransmitidos to set
     */
    public void setA08AltasAnualTransmitidos(long a08AltasAnualTransmitidos) {
        this.a08AltasAnualTransmitidos = a08AltasAnualTransmitidos;
    }

    /**
     * @return the a07CambiosMesTransmitidos
     */
    public long getA07CambiosMesTransmitidos() {
        return a07CambiosMesTransmitidos;
    }

    /**
     * @param a07CambiosMesTransmitidos the a07CambiosMesTransmitidos to set
     */
    public void setA07CambiosMesTransmitidos(long a07CambiosMesTransmitidos) {
        this.a07CambiosMesTransmitidos = a07CambiosMesTransmitidos;
    }

    /**
     * @return the a07CambiosAnualTransmitidos
     */
    public long getA07CambiosAnualTransmitidos() {
        return a07CambiosAnualTransmitidos;
    }

    /**
     * @param a07CambiosAnualTransmitidos the a07CambiosAnualTransmitidos to set
     */
    public void setA07CambiosAnualTransmitidos(long a07CambiosAnualTransmitidos) {
        this.a07CambiosAnualTransmitidos = a07CambiosAnualTransmitidos;
    }

    /**
     * @return the a02BajasMesTransmitidos
     */
    public long getA02BajasMesTransmitidos() {
        return a02BajasMesTransmitidos;
    }

    /**
     * @param a02BajasMesTransmitidos the a02BajasMesTransmitidos to set
     */
    public void setA02BajasMesTransmitidos(long a02BajasMesTransmitidos) {
        this.a02BajasMesTransmitidos = a02BajasMesTransmitidos;
    }

    /**
     * @return the a02BajasAnualTransmitidos
     */
    public long getA02BajasAnualTransmitidos() {
        return a02BajasAnualTransmitidos;
    }

    /**
     * @param a02BajasAnualTransmitidos the a02BajasAnualTransmitidos to set
     */
    public void setA02BajasAnualTransmitidos(long a02BajasAnualTransmitidos) {
        this.a02BajasAnualTransmitidos = a02BajasAnualTransmitidos;
    }

    /**
     * @return the totalMesTransmitidos
     */
    public long getTotalMesTransmitidos() {
        return totalMesTransmitidos;
    }

    /**
     * @param totalMesTransmitidos the totalMesTransmitidos to set
     */
    public void setTotalMesTransmitidos(long totalMesTransmitidos) {
        this.totalMesTransmitidos = totalMesTransmitidos;
    }

    /**
     * @return the totalAnualTransmitidos
     */
    public long getTotalAnualTransmitidos() {
        return totalAnualTransmitidos;
    }

    /**
     * @param totalAnualTransmitidos the totalAnualTransmitidos to set
     */
    public void setTotalAnualTransmitidos(long totalAnualTransmitidos) {
        this.totalAnualTransmitidos = totalAnualTransmitidos;
    }
}
