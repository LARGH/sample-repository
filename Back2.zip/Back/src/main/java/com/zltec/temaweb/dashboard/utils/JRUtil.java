/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: JRUtil.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.utils;

import java.lang.reflect.Method;

import java.math.BigDecimal;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

public class JRUtil {
    static ScriptEngineManager manager = new ScriptEngineManager();
    static ScriptEngine engine = manager.getEngineByName("js");
    public static final Map<String, SseEmitter> clientesDashboard = new HashMap<>();

    /**
     * Este método copia todas las propiedades en cascada que sean identicas en nombre  y tipo de retorno de un bean a un entity o viceversa
     * @param to
     * @param from
     */
    public static void copyProperties(Object to, Object from) {
        Method[] metodos = from.getClass().getMethods();
        Class<?>[] types = new Class[] { };
        Object[] args = new Object[] { };
        for (Method metodo : metodos) {
            String name = metodo.getName();
            Method metodoGetTo = null;
            Method metodoSetTo = null;
            Method metodoGetFrom = null;
            Object objFrom = null;
            Object objAux = null;
            String get = null;
            if (name.startsWith("set")) {
                try {
                    get = name.replaceFirst("set", "get");
                    metodoGetTo = to.getClass().getMethod(get, types);
                    metodoSetTo = to.getClass().getMethod(name, metodoGetTo.getReturnType());
                    metodoGetFrom = from.getClass().getMethod(get, types);
                    objFrom = metodoGetFrom.invoke(from, args);
                    metodoSetTo.invoke(to, objFrom);
                } catch (NoSuchMethodException nsme) {
                } catch (IllegalArgumentException ilegal) {
                    try {
                        objAux = metodoGetTo.getReturnType().getDeclaredConstructor().newInstance();
                        copyProperties(objAux, objFrom);
                        metodoSetTo.invoke(to, objAux);
                    } catch (Exception ex) {
                    }
                } catch (Exception e) {
                }
            }
        }
    }

    public static String getAnioMes() {
        Calendar fecha = Calendar.getInstance();
        int anio = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH) + 1;
        String anioMes = anio + "_" + (mes < 10 ? "0" + mes : mes);
        return anioMes;
    }

    public static String getAnioMesAnterior() {
        Calendar fecha = Calendar.getInstance();
        int anio = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH) + 1;
        if (mes == 1) {
            anio = anio - 1;
            mes = 12;
        } else {
            mes = mes - 1;
        }
        String anioMes = anio + "_" + (mes < 10 ? "0" + mes : mes);
        return anioMes;
    }

    public static String getDiaActual() {
        Calendar fecha = Calendar.getInstance();
        int dia = fecha.get(Calendar.DAY_OF_MONTH);
        String diaActual = dia < 10 ? "0" + dia : "" + dia;
        return diaActual;
    }

    public static int getDiaDelMes() {
        Calendar fecha = Calendar.getInstance();
        return fecha.get(Calendar.DAY_OF_MONTH);
    }

    public static int getUltimoDiaMesAnterior() {
        Calendar fecha = Calendar.getInstance();
        int anio = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH) - 1;
        int dia = fecha.get(Calendar.DAY_OF_MONTH);
        fecha.set(anio, mes, dia);
        if (mes <= 0 || mes == 1) {
            anio = fecha.get(Calendar.YEAR) - 1;
            mes = 12;
            dia = 1;
            fecha.set(anio, mes, dia);
        }
        int ultimoDia = fecha.getActualMaximum(Calendar.DAY_OF_MONTH);
        return ultimoDia;
    }

    public static Date getFechaUltimoDiaMesAnterior() {
        Calendar fecha = Calendar.getInstance();
        int anio = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH) - 1;
        int dia = fecha.get(Calendar.DAY_OF_MONTH);
        fecha.set(anio, mes, dia);
        if (mes <= 0 || mes == 1) {
            anio = fecha.get(Calendar.YEAR) - 1;
            mes = 12;
            dia = 1;
            fecha.set(anio, mes, dia);
        }
        int ultimoDia = fecha.getActualMaximum(Calendar.DAY_OF_MONTH);
        fecha.set(anio, mes, ultimoDia);
        return fecha.getTime();
    }

    public static Date getUltimoDiaMesActual() {
        Calendar fecha = Calendar.getInstance();
        int anio = fecha.get(Calendar.YEAR);
        int mes = fecha.get(Calendar.MONTH) + 1;
        int dia = fecha.get(Calendar.DAY_OF_MONTH);
        int ultimoDia = fecha.getActualMaximum(dia);
        Calendar cal = Calendar.getInstance();
        cal.set(anio, mes, ultimoDia);
        return cal.getTime();
    }

    public static double interpolacion(int x, int n, BigDecimal a, BigDecimal b) throws Exception {
        engine.put("x", x); //x = 1 hasta n = número de errores
        engine.put("a", a);
        engine.put("b", b);
        engine.put("n", n);
        Object interpolLineal = engine.eval("x *((b - a) / (n + 1)) + a"); //(x * ((b - a) / (ii + 1)) + a)
        return (Double) interpolLineal;
    }
    
    public static int numeroRandom(int limite) {
        Random rand = new Random();
        return rand.nextInt(limite)+1;
    }
}
