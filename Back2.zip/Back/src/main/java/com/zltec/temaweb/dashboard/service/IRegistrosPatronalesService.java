/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: IRegistrosPatronalesService.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.service;

import com.zltec.temaweb.dashboard.dominio.DominioDashboardResponse;
import com.zltec.temaweb.dashboard.excepcion.CustomException;

/**
 *
 * @author Jaime Landa
 */
public interface IRegistrosPatronalesService {
    public void getRegistrosPatronales(DominioDashboardResponse dom) throws CustomException;
}
