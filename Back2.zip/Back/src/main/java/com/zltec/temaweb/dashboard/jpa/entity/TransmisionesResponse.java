/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: TransmisionesResponse.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.jpa.entity;
/**
 *
 * @author Jaime Landa
 */
public class TransmisionesResponse implements java.io.Serializable {
    private Long bajas;
    private Long cambios;
    private Long altas;

    /**
     * @return the bajas
     */
    public Long getBajas() {
        return bajas;
    }

    /**
     * @param bajas the bajas to set
     */
    public void setBajas(Long bajas) {
        this.bajas = bajas;
    }

    /**
     * @return the cambios
     */
    public Long getCambios() {
        return cambios;
    }

    /**
     * @param cambios the cambios to set
     */
    public void setCambios(Long cambios) {
        this.cambios = cambios;
    }

    /**
     * @return the altas
     */
    public Long getAltas() {
        return altas;
    }

    /**
     * @param altas the altas to set
     */
    public void setAltas(Long altas) {
        this.altas = altas;
    }

}
