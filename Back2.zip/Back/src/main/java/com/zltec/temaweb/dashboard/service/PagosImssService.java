/**
 * Copyright 2022 Z&L Tecnology.
 * Elaborado por Z&L Tecnology.
 * Se prohíbe la reproducción total y/o parcial.
 * Web Site: https://zltec-temaweb.com.mx.
 * Nombre de Aplicación: TemaWeb30
 * Nombre de archivo: PagosImssService.java
 * Fecha de creación: Abril, 2022
 * @author: Jaime Landa
 * @version 1.0
 *
 * Bitácora de modificaciones:
 * CR/Defecto 		Fecha 			Autor 			Descripción del cambio
 * ----------------------------------------------------------------------------
**/
package com.zltec.temaweb.dashboard.service;

import com.zltec.temaweb.dashboard.dominio.DominioDashboardResponse;
import com.zltec.temaweb.dashboard.excepcion.CustomException;
import com.zltec.temaweb.dashboard.repository.IPagosImssRepository;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author Jaime Landa
 */
@Service
public class PagosImssService implements IPagosImssService {
    private static final Logger LOG = LoggerFactory.getLogger(PagosImssService.class);
    @Autowired
    private IPagosImssRepository pagosImssRepository;

    @Override
    public void getPagosImss(DominioDashboardResponse dom) throws CustomException {
        LOG.info("##### User10: "+dom.getUsername());
        LOG.info("##### Clave de División: "+dom.getClaveDivision());
        Map<String, Object> responseXMes = pagosImssRepository.
                filtraPagosImssXMes(dom.getClavePatronal());
        if(responseXMes != null) {
            setResponseTransmisionesXMes(dom, responseXMes);
        }
        Map<String, Object> responseAnual = pagosImssRepository.
                filtraPagosImssAnual(dom.getClavePatronal());
        if(responseAnual != null) {
            setResponseTransmisionesAnual(dom, responseAnual);
        }
    }
    
    private void setResponseTransmisionesXMes(DominioDashboardResponse dom, Map<String, Object> responseXMes) {
        if(responseXMes.get("imss") != null) {
            dom.getPagosImss().setImss(Long.parseLong(""+responseXMes.get("imss")));
        }
        if(responseXMes.get("rcv") != null) {
            dom.getPagosImss().setRcv(Long.parseLong(""+responseXMes.get("rcv")));
        }
        if(responseXMes.get("info") != null) {
            dom.getPagosImss().setInfo(Long.parseLong(""+responseXMes.get("info")));
        }
        dom.getPagosImss().setTotalMes(dom.getPagosImss().getImss()+dom.getPagosImss().getRcv()+dom.getPagosImss().getInfo());
    }
    
    private void setResponseTransmisionesAnual(DominioDashboardResponse dom, Map<String, Object> responseAnual) {
        if(responseAnual.get("imss") != null) {
            dom.getPagosImss().setImss(Long.parseLong(""+responseAnual.get("imss")));
        }
        if(responseAnual.get("rcv") != null) {
            dom.getPagosImss().setRcv(Long.parseLong(""+responseAnual.get("rcv")));
        }
        if(responseAnual.get("info") != null) {
            dom.getPagosImss().setInfo(Long.parseLong(""+responseAnual.get("info")));
        }
        dom.getPagosImss().setTotalAnual(dom.getPagosImss().getImss()+dom.getPagosImss().getRcv()+dom.getPagosImss().getInfo());
    }
}
